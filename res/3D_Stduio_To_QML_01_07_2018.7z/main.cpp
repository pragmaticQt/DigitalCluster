#include <QApplication>
#include <QQuickView>
#include <QSurfaceFormat>
#include <q3dsruntimeglobal.h>

int main(int argc, char *argv[])
{
    qputenv("QSG_INFO", "1");
    QApplication app(argc, argv);

    // Use the ideal format (i.e. OpenGL version and profile) recommended by
    // the Qt 3D Studio runtime. Without this the format set on the QQuickView
    // would be used instead.
    QSurfaceFormat::setDefaultFormat(Q3DS::surfaceFormat());

    QQuickView viewer;
    viewer.setSource(QUrl("qrc:/Main.qml"));

    viewer.setTitle(QStringLiteral("Integration of Qt3D Studio - Part 1"));
    viewer.setResizeMode(QQuickView::SizeRootObjectToView);
    viewer.resize(1280, 480);
    viewer.show();

    return app.exec();
}
